import "./styles.css";
import React from "react";
import Form from "./components/Form";

const App = () => {
  return (
    <div className="App">
      <div className="App-content">
        <p>Aquí haremos nuestra lista rapida</p>
        <Form />
      </div>
    </div>
  );
};

export default App;
